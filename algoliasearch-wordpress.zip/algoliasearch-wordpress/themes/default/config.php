<?php

return array(
    'name'                      => 'Default',
    'screenshot'                => 'screenshot.png',
    'screenshot-autocomplete'   => 'screenshot-autocomplete.png',
    'facet_types'               => array('slider' => 'Slider')
);