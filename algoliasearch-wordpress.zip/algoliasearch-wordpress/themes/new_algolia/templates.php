<script type="text/template" id="autocomplete-template">
    <div class="result">
        <div class="title">
            {{#featureImage}}
            <img style="width: 30px" src="{{{ featureImage.sizes.thumbnail.file }}}" />
            {{/featureImage}}
            {{{ _highlightResult.title.value }}}
        </div>
    </div>
</script>

<script type="text/template" id="instant-content-template">
    <div class="search-sorting">
        <span class="label">Sort by</span>
        <select id="index_to_use">
            <option {{#sortSelected}}{{relevance_index_name}}{{/sortSelected}} value="{{relevance_index_name}}">Relevance</option>
            {{#sorting_indices}}
            <option {{#sortSelected}}{{index_name}}{{/sortSelected}} value="{{index_name}}">{{label}}</option>
            {{/sorting_indices}}
        </select>
    </div>
    <div class="cf"></div>
    {{#hits}}
        {{^query}}
            <div class="d-1of3 t-1of2">
                <article class="grid-entry">
                    <header class="article-header">
                        <a href="{{permalink}}"><img class="entry-illus" src="{{featureImage.sizes.medium.file}}"/></a>
                        <h1 class="h3 entry-title"><a href="{{permalink}}">{{{ _highlightResult.title.value }}}</a></h1>
                    </header>
                </article>
            </div>
        {{/query}}

        {{#query}}
            <div>
                <article class="grid-entry grid-entry--detailled">
                    <div class="d-1of3">
                        <a href="{{permalink}}"><img class="entry-illus" src="{{featureImage.sizes.medium.file}}"/></a>
                    </div>
                    <div class="d-2of3">
                        <h1 class="h3 entry-title"><a href="{{permalink}}">{{{ _highlightResult.title.value }}}</a></h1>

                        <span class="entry-author">
                            <img class="author-avatar" src="http://d3ibatyzauff7b.cloudfront.net/assets/about-{{author}}.jpg"/>
                            {{ author }}
                        </span>
                        <p class="entry-desc">{{{ _snippetResult.content_stripped.value }}}</p>

                        <ul class="tags">
                        {{#post_tag}}
                            <li>#{{.}}</li>
                        {{/post_tag}}
                        </ul>
                    </div>
                    <div class="cf"></div>
                </article>
            </div>
        {{/query}}

    {{/hits}}
    {{^hits.length}}
    <div class="no-result">
        No results
    </div>
    {{/hits.length}}
</script>


<script type="text/template" id="instant-facets-template">
    {{#facets}}
    {{#count}}
    <div class="search-filters">
        <span class="label">
            {{ facet_categorie_name }}
        </span>
        <ul>
            {{#sub_facets}}

                {{#type.conjunctive}}
                <li class="{{#checked}} checked {{/checked}} sub_facet conjunctive">
                    <input style="display: none;" data-tax="{{tax}}" {{#checked}} checked {{/checked}} data-name="{{name}}" class="facet_value" type="checkbox" />
                    {{name}} {{#count}}({{count}}){{/count}}
                </li>
                {{/type.conjunctive}}

                {{#type.disjunctive}}
                <li class="{{#checked}} checked {{/checked}} sub_facet disjunctive">
                    <input style="display: none;" data-tax="{{tax}}" {{#checked}} checked {{/checked}} data-name="{{name}}" class="facet_value" type="checkbox" />
                    {{name}} {{#count}}({{count}}){{/count}}
                </li>
                {{/type.disjunctive}}

                {{#type.menu}}
                <li data-tax="{{tax}}" data-name="{{nameattr}}" data-type="menu" class="{{#checked}}checked {{/checked}}sub_facet disjunctive menu {{#category}}category{{/category}}">
                    <input style="display: none;" data-tax="{{tax}}" {{#checked}}checked{{/checked}} data-name="{{nameattr}}" class="facet_value" type="checkbox" />
                    {{name}} {{#print_count}}{{#count}}({{count}}){{/count}}{{/print_count}}
                </li>
                {{/type.menu}}

            {{/sub_facets}}
        </ul>
    </div>
    {{/count}}
    {{/facets}}
</script>



<script type="text/template" id="instant-pagination-template">
    <div class="pagination-wrapper cf">
        <ul class="pagination">
            <li {{^prev_page}}class="disabled"{{/prev_page}}>
                <a href="#" data-page="{{prev_page}}">
                    Previous
                </a>
            </li>

            {{#pages}}
            <li class="{{#current}}active{{/current}}{{#disabled}}disabled{{/disabled}}">
                <a href="#" data-page="{{number}}">
                    {{ number }}
                </a>
            </li>
            {{/pages}}

            <li {{^next_page}}class="disabled"{{/next_page}}>
                <a href="#" data-page="{{next_page}}">
                    Next
                </a>
            </li>
        </ul>
    </div>
</script>
