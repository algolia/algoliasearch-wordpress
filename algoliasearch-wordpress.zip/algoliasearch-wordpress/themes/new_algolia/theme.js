//back
window.goBack = function (e){
    var defaultLocation = "/";
    var oldHash = window.location.hash;

    history.back(); // Try to go back

    var newHash = window.location.hash;

    if(
        newHash === oldHash &&
        (typeof(document.referrer) !== "string" || document.referrer  === "")
    ){
        window.setTimeout(function(){
            // redirect to default location
            window.location.href = defaultLocation;
        },1000); // set timeout in ms
    }
    if(e){
        if(e.preventDefault)
            e.preventDefault();
        if(e.preventPropagation)
            e.preventPropagation();
    }
    return false; // stop event propagation and browser default event
}


jQuery(document).ready(function ($) {


    if (algoliaSettings.type_of_search == "instant")
    {
        /**
         * Variables Initialization
         */

        var old_content         = $(algoliaSettings.instant_jquery_selector).html();

        var resultsTemplate     = Hogan.compile($('#instant-content-template').text());
        var facetsTemplate      = Hogan.compile($('#instant-facets-template').text());
        var paginationTemplate  = Hogan.compile($('#instant-pagination-template').text());

        var conjunctive_facets  = [];
        var disjunctive_facets  = [];

        for (var i = 0; i < algoliaSettings.facets.length; i++)
        {
            if (algoliaSettings.facets[i].type == "conjunctive")
                conjunctive_facets.push(algoliaSettings.facets[i].tax);

            if (algoliaSettings.facets[i].type == "disjunctive")
                disjunctive_facets.push(algoliaSettings.facets[i].tax);

            if (algoliaSettings.facets[i].type == "slider")
                disjunctive_facets.push(algoliaSettings.facets[i].tax);

            if (algoliaSettings.facets[i].type == "menu")
                disjunctive_facets.push(algoliaSettings.facets[i].tax);
        }

        algoliaSettings.facets = algoliaSettings.facets.sort(facetsCompare);


        engine.setHelper(new AlgoliaSearchHelper(algolia_client, algoliaSettings.index_name + 'all', {
            facets: conjunctive_facets,
            disjunctiveFacets: disjunctive_facets,
            hitsPerPage: algoliaSettings.number_by_page
        }));

        /**
         * Functions
         */

        function performQueries(push_state)
        {
            engine.helper.search(engine.query, searchCallback);

            engine.updateUrl(push_state);
        }

        function searchCallback(success, content)
        {
            if (success)
            {
                var html_content = "";

                html_content += "<div id='algolia_instant_selector'>";

                var facets = [];
                var pages = [];

                if (content.hits.length > 0)
                {
                    facets = engine.getFacets(content);
                    pages = engine.getPages(content);

                    html_content += engine.getHtmlForFacets(facetsTemplate, facets);
                }

                html_content += engine.getHtmlForResults(resultsTemplate, content, facets);

                if (content.hits.length > 0)
                    html_content += engine.getHtmlForPagination(paginationTemplate, content, pages, facets);

                html_content += "</div>";

                $(algoliaSettings.instant_jquery_selector).html(html_content);

                updateSliderValues();
            }
        }

        /**
         * Custom Facets Types
         */

        custom_facets_types["slider"] = function (engine, content, facet) {

            if (content.facets_stats[facet.tax] != undefined)
            {
                var min = content.facets_stats[facet.tax].min;
                var max = content.facets_stats[facet.tax].max;

                var current_min = engine.helper.getNumericsRefine(facet.tax, ">=");
                var current_max = engine.helper.getNumericsRefine(facet.tax, "<=");

                if (current_min == undefined)
                    current_min = min;

                if (current_max == undefined)
                    current_max = max;

                var params = {
                    type: {},
                    current_min: current_min,
                    current_max: current_max,
                    count: min == max ? 0 : 1,
                    min: min,
                    max: max
                };

                params.type[facet.type] = true;

                return [params];
            }

            return [];
        };

        custom_facets_types["menu"] = function (engine, content, facet) {

            var data = [];

            var all_count = 0;
            var all_unchecked = true;

            for (var key in content.disjunctiveFacets[facet.tax])
            {
                var checked = engine.helper.isRefined(facet.tax, key);

                all_unchecked = all_unchecked && !checked;

                var name = algoliaSettings.facetsLabels[key] != undefined ? algoliaSettings.facetsLabels[key] : key;
                var nameattr = key;

                var params = {
                    type: {},
                    checked: checked,
                    nameattr: nameattr,
                    name: name,
                    print_count: true,
                    category: 1,
                    count: content.disjunctiveFacets[facet.tax][key]
                };

                all_count += content.disjunctiveFacets[facet.tax][key];

                params.type[facet.type] = true;

                data.push(params);
            }

            var params = {
                type: {},
                checked: all_unchecked,
                nameattr: 'all',
                name: 'All',
                print_count: true,
                category: 1,
                count: all_count
            };

            params.type[facet.type] = true;

            data.unshift(params);

            return data;
        };

        /**
         * Bindings
         */

        $("body").on("click", ".sub_facet.menu", function (e) {

            e.stopImmediatePropagation();

            if ($(this).attr("data-name") == "all")
                engine.helper.removeDisjunctiveRefinements($(this).attr("data-tax"));

            $(this).find("input[type='checkbox']").each(function (i) {
                $(this).prop("checked", !$(this).prop("checked"));

                if (false == engine.helper.isRefined($(this).attr("data-tax"), $(this).attr("data-name")))
                    engine.helper.removeDisjunctiveRefinements($(this).attr("data-tax"));

                if ($(this).attr("data-name") != "all")
                    engine.helper.toggleRefine($(this).attr("data-tax"), $(this).attr("data-name"));
            });

            engine.helper.setPage(0);

            performQueries(true);
        });

        $("body").on("click", ".sub_facet", function () {

            $(this).find("input[type='checkbox']").each(function (i) {
                $(this).prop("checked", !$(this).prop("checked"));

                engine.helper.toggleRefine($(this).attr("data-tax"), $(this).attr("data-name"));
            });

            engine.helper.setPage(0);

            performQueries(true);
        });


        $("body").on("slide", "", function (event, ui) {
            updateSlideInfos(ui);
        });

        var sortHasChanged = false;

        $("body").on("change", "#index_to_use", function () {

            sortHasChanged = true;

            engine.helper.setIndex($(this).val());

            engine.helper.setPage(0);

            performQueries(true);
        });

        $("body").on("slidechange", ".algolia-slider-true", function (event, ui) {

            var slide_dom = $(ui.handle).closest(".algolia-slider");
            var min = slide_dom.slider("values")[0];
            var max = slide_dom.slider("values")[1];

            if (parseInt(slide_dom.slider("values")[0]) >= parseInt(slide_dom.attr("data-min")))
                engine.helper.addNumericsRefine(slide_dom.attr("data-tax"), ">=", min);
            if (parseInt(slide_dom.slider("values")[1]) <= parseInt(slide_dom.attr("data-max")))
                engine.helper.addNumericsRefine(slide_dom.attr("data-tax"), "<=", max);

            if (parseInt(min) == parseInt(slide_dom.attr("data-min")))
                engine.helper.removeNumericRefine(slide_dom.attr("data-tax"), ">=");

            if (parseInt(max) == parseInt(slide_dom.attr("data-max")))
                engine.helper.removeNumericRefine(slide_dom.attr("data-tax"), "<=");

            engine.helper.setPage(0);

            updateSlideInfos(ui);
            performQueries(true);
        });

        $("body").on("click", ".pagination a", function (e) {
            e.preventDefault();

            if ($(this).closest("li").hasClass("disabled"))
                return false;

            engine.gotoPage($(this).attr("data-page"));

            performQueries(true);

            $("body").scrollTop(0);

            return false;
        });

        $(algoliaSettings.search_input_selector).keyup(function (e) {
            e.preventDefault();

            var $this = $(this);

            if (sortHasChanged === false) {
                $('#index_to_use').val(algoliaSettings.index_name + 'all');
                engine.helper.setIndex(algoliaSettings.index_name + 'all');
            }

            engine.query = $(this).val();

            //if ($(this).val().length == 0) {
              //  clearTimeout(history_timeout);
                //location.replace('#');
                //$(algoliaSettings.instant_jquery_selector).html(old_content);
                //return;
            //}

            /* Uncomment to clear refinements on keyup */

            //engine.helper.clearRefinements();
            //engine.helper.clearNumericRefinements();


            performQueries(false);

            return false;
        });

        function updateSliderValues()
        {
            $(".algolia-slider-true").each(function (i) {
                var min = $(this).attr("data-min");
                var max = $(this).attr("data-max");

                var new_min = engine.helper.getNumericsRefine($(this).attr("data-tax"), ">=");
                var new_max = engine.helper.getNumericsRefine($(this).attr("data-tax"), "<=");

                if (new_min != undefined)
                    min = new_min;

                if (new_max != undefined)
                    max = new_max;

                $(this).slider({
                    min: parseInt($(this).attr("data-min")),
                    max: parseInt($(this).attr("data-max")),
                    range: true,
                    values: [min, max]
                });
            });
        };

        function updateSlideInfos(ui)
        {
            var infos = $(ui.handle).closest(".algolia-slider").nextAll(".algolia-slider-info");

            infos.find(".min").html(ui.values[0]);
            infos.find(".max").html(ui.values[1]);
        }

        /**
         * Initialization
         */

        $(algoliaSettings.search_input_selector).attr('autocomplete', 'off');

        engine.getRefinementsFromUrl(searchCallback);

        window.addEventListener("popstate", function(e) {
            engine.getRefinementsFromUrl(searchCallback);
        });


        /** clear search button **/
        $('#search-input-wrapper').append('<span class="btn-clear-input hide"></span>');

        $('.btn-clear-input').on('click', function(){
            $('#search-input').val(null);
            $(this).addClass('hide');
            engine.query = '';
            engine.performQueries(true);
        });

        $('#search-input').on('keyup focus', function(){
            if ( $(this).val().length === 0 ){
                $('.btn-clear-input').addClass('hide');
            }
            else {
                $('.btn-clear-input').removeClass('hide');
            }
        });

        $('#search-input-wrapper').append('<span class="btn-clear-input hide"></span>');

        if (! $('body').hasClass('home') )
        {
            searchButton = $("<button id='search-button' type='button'>Search</button>");
            searchButton.click(function() {
                $(this).toggleClass('search-button--close');
                $('.algoliasearchcontainer').toggleClass('hide');
                $('.single-back').toggleClass('hide');
                $('.post-content').toggleClass('hide');
                $('#search-input-wrapper').toggleClass('hide').find('input').focus();
            });
            $("header.header").append(searchButton);
        };


        engine.helper.setIndex(algoliaSettings.index_name + 'all_date_desc');

        /** Don't change the sort if page loaded with URL params **/
        if ($(algoliaSettings.search_input_selector).val() !== "" || !$.isEmptyObject(engine.helper.refinements) || !$.isEmptyObject(engine.helper.disjunctiveRefinements) || engine.helper.index != algoliaSettings.index_name + "all_date_desc") {
            sortHasChanged = true;
        }

        performQueries(false);
    }
});