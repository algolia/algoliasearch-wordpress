<?php

return array(
    'name'                      => 'New Algolia',
    'screenshot'                => 'screenshot.png',
    'screenshot-autocomplete'   => 'screenshot.png',
    'facet_types'               => array('menu' => 'Menu')
);