<?php

return array(
    'name'                      => 'Woo Default',
    'screenshot'                => 'screenshot.png',
    'screenshot-autocomplete'   => 'screenshot-autocomplete.png',
    'facet_types'               => array('slider' => 'Slider', 'menu' => 'Menu')
);