<?php

return array(
    'name'                      => 'Algolia',
    'screenshot'                => 'screenshot.png',
    'screenshot-autocomplete'   => 'screenshot-autocomplete.png'
);